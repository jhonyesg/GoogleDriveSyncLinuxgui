"""
lX Drive - Cliente de sincronización multi-cuenta para Google Drive
"""

__version__ = "1.0.0"
__author__ = "J. Suarez"
__description__ = "Alternativa opensource a Insync para Linux"
