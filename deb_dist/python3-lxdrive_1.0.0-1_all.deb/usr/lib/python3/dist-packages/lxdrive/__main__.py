#!/usr/bin/env python3
"""
Punto de entrada principal para lX Drive
"""

import sys
from lxdrive.app import main

if __name__ == "__main__":
    sys.exit(main())
